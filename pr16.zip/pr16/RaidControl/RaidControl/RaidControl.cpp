﻿// RaidControl.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <Windows.h>

using namespace std;

//struct Bayum
//{
//    long long health = 2200000;
//    int resist = 44;
//    int damage = 73843;
//    int specialDamage = 150000;
//    int attackCooldown = 5;
//    int specialCooldown = 10;
//};
//
//struct Player
//{
//    long long health = 500000;
//    int damage = 12000;
//    int specialDamage = 30000;
//    int attackCooldown = 2;
//    int specialCooldown = 5;
//    int defense = 20;
//    int dodgeChance = 15;
//    char name[64];
//};

#define EVENT_START_NAME L"Global\\RaidStartEvent"
#define EVENT_PAUSE_NAME L"Global\\RaidPauseEvent"
#define EVENT_STOP_NAME L"Global\\RaidStopEvent"
#define EVENT_SPECIAL_NAME L"Global\\BossSpecialEvent"
#define MUTEX_DATA_NAME L"Global\\RaidDataMutex"

int main()
{
    setlocale(NULL, "Russian");

    HANDLE hmutex = CreateMutex(NULL, FALSE, MUTEX_DATA_NAME);
    if (hmutex == NULL)
    {
        cout << "Мьютекс не создан\n ";
        return GetLastError();
    }

    HANDLE eventStart = CreateEvent(NULL, TRUE, FALSE, EVENT_START_NAME);
    if (eventStart == NULL)
    {
        cout << "Ивент не создан\n ";
        return GetLastError();
    }

    HANDLE eventPause = CreateEvent(NULL, TRUE, FALSE, EVENT_PAUSE_NAME);
    if (eventPause == NULL)
    {
        cout << "Ивент не создан\n ";
        return GetLastError();
    }

    HANDLE eventStop = CreateEvent(NULL, TRUE, FALSE, EVENT_STOP_NAME);
    if (eventStop == NULL)
    {
        cout << "Ивент не создан\n ";
        return GetLastError();
    }

    HANDLE eventSpecial = CreateEvent(NULL, TRUE, FALSE, EVENT_SPECIAL_NAME);
    if (eventSpecial == NULL)
    {
        cout << "Ивент не создан\n ";
        return GetLastError();
    }

    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);

    int numPla;
    cout << "Введите количество игроков (1-10): ";
    cin >> numPla;

    wchar_t cmdLine[256];
    swprintf_s(cmdLine, L"..\\..\\GameServer\\x64\\Debug\\GameServer.exe %d", numPla);

    BOOL result = CreateProcess(NULL, cmdLine, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
    if (result == FALSE)
    {
        cout << "Процесс не создан\n";
        return 1;
    }

    int choise;

    while (true)
    {
        cout << "1. Старт\n";
        cout << "2. Пауза\n";
        cout << "3. Продолжить\n";
        cout << "4. Стоп\n";
        cout << "0. Выход\n";

        cin >> choise;

        switch (choise)
        {
        case 1:
            SetEvent(eventStart);
            break;
        case 2:
            SetEvent(eventPause);
            break;
        case 3:
            ResetEvent(eventPause);
            break;
        case 4:
            SetEvent(eventStop);
            break;
        case 0:
            SetEvent(eventStop);
            CloseHandle(hmutex);
            CloseHandle(eventStart);
            CloseHandle(eventPause);
            CloseHandle(eventSpecial);
            CloseHandle(eventStop);
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
            return 0;
        default:
            cout << "Введите еще раз\n";

        }
    }

    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
