﻿// GameServer.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <Windows.h>
#include <cstdlib>

using namespace std;

struct Bayum
{
    long long health = 2200000;
    int resist = 44;
    int damage = 73843;
    int specialDamage = 150000;
    int attackCooldown = 5;
    int specialCooldown = 10;
};

struct Player
{
    long long health = 500000;
    int damage = 12000;
    int specialDamage = 30000;
    int attackCooldown = 2;
    int specialCooldown = 5;
    int defense = 20;
    int dodgeChance = 15;
    char name[64];
    long long totalDamageDealt = 0;
};

#define EVENT_START_NAME L"Global\\RaidStartEvent"
#define EVENT_PAUSE_NAME L"Global\\RaidPauseEvent"
#define EVENT_STOP_NAME L"Global\\RaidStopEvent"
#define EVENT_SPECIAL_NAME L"Global\\BossSpecialEvent"
#define MUTEX_DATA_NAME L"Global\\RaidDataMutex"

Bayum g_boss;
Player g_players[10];
int g_numPla = 0;

HANDLE g_eventPause;
HANDLE g_eventStop;
HANDLE g_eventSpecial;
HANDLE g_mutex;

bool g_battleOver = false;

DWORD WINAPI BossThread(LPVOID lpParam)
{
    cout << "Поток босса запущен. HP: " << g_boss.health << endl;
    int attackCooldown = 0;
    int specialCooldown = g_boss.specialCooldown * 10;

    while (g_boss.health > 0 && !g_battleOver)
    {
        if (WaitForSingleObject(g_eventPause, 0) == WAIT_OBJECT_0)
        {
            WaitForSingleObject(g_eventPause, INFINITE);
        }
        if (WaitForSingleObject(g_eventStop, 0) == WAIT_OBJECT_0)
        {
            g_battleOver = true;
            break;
        }

        if (attackCooldown > 0) 
        {
            attackCooldown--;
        }
        else {
            WaitForSingleObject(g_mutex, INFINITE);

            int alivePlayers[10];
            int aliveCount = 0;
            for (int i = 0; i < g_numPla; i++)
            {
                if (g_players[i].health > 0)
                {
                    alivePlayers[aliveCount++] = i;
                }
            }

            if (aliveCount > 0) 
            {
                int targetIdx = alivePlayers[rand() % aliveCount];

                if (rand() % 100 < g_players[targetIdx].dodgeChance) 
                {
                    cout << g_players[targetIdx].name << " уклонился от атаки босса!" << endl;
                }
                else 
                {
                    int dmg = g_boss.damage * (100 - g_players[targetIdx].defense) / 100;
                    g_players[targetIdx].health -= dmg;
                    cout << "Босс бьет " << g_players[targetIdx].name << " на " << dmg << ". HP игрока: " << g_players[targetIdx].health << endl;
                }
            }
            ReleaseMutex(g_mutex);
            attackCooldown = g_boss.attackCooldown * 10;
        }

        if (specialCooldown > 0)
        {
            specialCooldown--;
        }
        else
        {
            WaitForSingleObject(g_mutex, INFINITE);

            int aliveCount = 0;
            for (int i = 0; i < g_numPla; i++)
            {
                if (g_players[i].health > 0) aliveCount++;
            }

            if (aliveCount > 0) {
                cout << "!!! БОСС ПРИМЕНЯЕТ СПЕЦИАЛЬНУЮ АТАКУ !!!" << endl;
                int dmg = g_boss.specialDamage * (1 - 0.05 * (aliveCount - 1));

                for (int i = 0; i < g_numPla; i++)
                {
                    if (g_players[i].health > 0) 
                    {
                        if (rand() % 100 < g_players[i].dodgeChance)
                        {
                            cout << g_players[i].name << " уклонился от спец. атаки!" << endl;
                        }
                        else
                        {
                            int finalDmg = dmg * (100 - g_players[i].defense) / 100;
                            g_players[i].health -= finalDmg;
                            cout << g_players[i].name << " получает " << finalDmg << " урона от спец. атаки. HP: " << g_players[i].health << endl;
                        }
                    }
                }
            }
            ReleaseMutex(g_mutex);
            specialCooldown = g_boss.specialCooldown * 10;
        }

        Sleep(100);
    }
    cout << "Поток босса завершен" << endl;
    return 0;
}

DWORD WINAPI PlayerThread(LPVOID lpParam)
{
    int id = *(int*)lpParam;
    cout << g_players[id].name << " готов к бою. HP: " << g_players[id].health << endl;

    int attackCooldown = 0;
    int specialCooldown = g_players[id].specialCooldown * 10;

    while (g_players[id].health > 0 && g_boss.health > 0 && !g_battleOver)
    {
        if (WaitForSingleObject(g_eventPause, 0) == WAIT_OBJECT_0)
        {
            WaitForSingleObject(g_eventPause, INFINITE);
        }
        if (WaitForSingleObject(g_eventStop, 0) == WAIT_OBJECT_0)
        {
            g_battleOver = true;
            break;
        }

        if (attackCooldown > 0)
        {
            attackCooldown--;
        }
        else
        {
            WaitForSingleObject(g_mutex, INFINITE);
            if (g_boss.health > 0)
            {
                int dmg = g_players[id].damage * (100 - g_boss.resist) / 100;
                g_boss.health -= dmg;
                g_players[id].totalDamageDealt += dmg;
                cout << g_players[id].name << " бьет босса на " << dmg << ". HP босса: " << g_boss.health << endl;
            }
            ReleaseMutex(g_mutex);
            attackCooldown = g_players[id].attackCooldown * 10;
        }

        if (specialCooldown > 0)
        {
            specialCooldown--;
        }
        else
        {
            WaitForSingleObject(g_mutex, INFINITE);
            if (g_boss.health > 0)
            {
                int dmg = g_players[id].specialDamage * (100 - g_boss.resist) / 100;
                g_boss.health -= dmg;
                g_players[id].totalDamageDealt += dmg;
                cout << g_players[id].name << " применяет СПЕЦ. АТАКУ на " << dmg << ". HP босса: " << g_boss.health << endl;
            }
            ReleaseMutex(g_mutex);
            specialCooldown = g_players[id].specialCooldown * 10;
        }

        Sleep(100);
    }
    cout << g_players[id].name << " завершил бой\n";
    return 0;
}

int main(int argc, char* argv[])
{
    DWORD startTime = GetTickCount();

    setlocale(NULL, "Russian");

    srand(time(NULL));

    int numPla = 3;
    if (argc > 1)
    {
        numPla = atoi(argv[1]);
        if (numPla < 1) numPla = 1;
        if (numPla > 10) numPla = 10;
    }
    g_numPla = numPla;

    g_mutex = OpenMutex(MUTEX_ALL_ACCESS, FALSE, MUTEX_DATA_NAME);
    if (g_mutex == NULL) 
    { 
        cout << "Мьютекс не создан\n"; 
        return 1; 
    }

    HANDLE eventStart = OpenEvent(EVENT_MODIFY_STATE | SYNCHRONIZE, FALSE, EVENT_START_NAME);
    if (eventStart == NULL) 
    { 
        cout << "Ивент не создан\n"; 
        return 1; 
    }

    g_eventPause = OpenEvent(EVENT_MODIFY_STATE | SYNCHRONIZE, FALSE, EVENT_PAUSE_NAME);
    if (g_eventPause == NULL) 
    { 
        cout << "Ивент не создан\n"; 
        return 1; 
    }

    g_eventStop = OpenEvent(EVENT_MODIFY_STATE | SYNCHRONIZE, FALSE, EVENT_STOP_NAME);
    if (g_eventStop == NULL) 
    { 
        cout << "Ивент не создан\n"; 
        return 1; 
    }

    g_eventSpecial = OpenEvent(EVENT_MODIFY_STATE | SYNCHRONIZE, FALSE, EVENT_SPECIAL_NAME);
    if (g_eventSpecial == NULL) 
    { 
        cout << "Ивент не создан\n"; 
        return 1; 
    }

    cout << "Сервер запущен. Ожидаю Старт\n";

    for (int i = 0; i < numPla; i++)
    {
        sprintf_s(g_players[i].name, "Игрок_%d", i + 1);
    }

    WaitForSingleObject(eventStart, INFINITE);

    cout << "Бой начался\n";

    HANDLE hBossThread = CreateThread(NULL, 0, BossThread, NULL, 0, NULL);

    HANDLE hPlayerThreds[10];
    int playerIds[10];
    for (int i = 0;i < g_numPla;i++)
    {
        playerIds[i] = i;
        hPlayerThreds[i] = CreateThread(NULL, 0, PlayerThread, &playerIds[i], 0, NULL);
    }

    WaitForSingleObject(hBossThread, INFINITE);
    for (int i = 0; i < g_numPla; i++) {
        WaitForSingleObject(hPlayerThreds[i], INFINITE);
    }

    cout << "\n БОЙ ЗАВЕРШЕН \n";
    DWORD endTime = GetTickCount();
    DWORD duration = (endTime - startTime) / 1000;
    cout << "\nПродолжительность боя: " << duration << " секунд\n";
    if (g_boss.health <= 0) {
        cout << "Победили ИГРОКИ\n";
    }
    else {
        cout << "Победил БОСС\n";
    }

    for (int i = 0; i < g_numPla - 1; i++)
    {
        for (int j = 0; j < g_numPla - i - 1; j++)
        {
            if (g_players[j].totalDamageDealt < g_players[j + 1].totalDamageDealt) 
            {
                Player temp = g_players[j];
                g_players[j] = g_players[j + 1];
                g_players[j + 1] = temp;
            }
        }
    }

    cout << "\nСтатистика игроков:\n";
    for (int i = 0; i < min(3, g_numPla); i++) {
        cout << i + 1 << ". " << g_players[i].name << " - урон: " << g_players[i].totalDamageDealt << endl;
    }

    CloseHandle(g_mutex);
    CloseHandle(eventStart);
    CloseHandle(g_eventStop);
    CloseHandle(g_eventSpecial);
    CloseHandle(g_eventPause);

    CloseHandle(hBossThread);
    for (int i = 0; i < g_numPla; i++) {
        CloseHandle(hPlayerThreds[i]);
    }

    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
